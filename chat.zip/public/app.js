const messagesEl = document.getElementById('messages');
const form = document.getElementById('chatForm');
const input = document.getElementById('messageInput');
const imageInput = document.getElementById('imageInput');
const sendBtn = document.getElementById('sendBtn');
const resetBtn = document.getElementById('resetBtn');
const fileHint = document.getElementById('fileHint');
const kbUploadInput = document.getElementById('kbUploadInput');
const kbFilesEl = document.getElementById('kbFiles');
const kbStatus = document.getElementById('kbStatus');
const webSearchToggle = document.getElementById('webSearchToggle');
const contextToggle = document.getElementById('contextToggle');
const contextCard = document.getElementById('contextCard');
let sessionId = localStorage.getItem('chat_session_id') || crypto.randomUUID();
localStorage.setItem('chat_session_id', sessionId);

async function loadHistory() {
  try {
    const res = await fetch(`/chat/api/history?sessionId=${encodeURIComponent(sessionId)}`);
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.ok) throw new Error(data.error || `HTTP ${res.status}`);
    sessionId = data.sessionId || sessionId;
    localStorage.setItem('chat_session_id', sessionId);
    messagesEl.innerHTML = '';
    const history = Array.isArray(data.messages) ? data.messages : [];
    if (!history.length) {
      addMessage('assistant', '你好，我是 caolaobancloud 聊天助手。聊天记录会保存在服务器本地，下次打开还能继续。');
      return;
    }
    history.forEach(m => addMessage(m.role, m.content));
  } catch (err) {
    messagesEl.innerHTML = '';
    addMessage('assistant', `历史记录加载失败：${err.message}`);
  }
}

async function loadKbFiles() {
  try {
    const res = await fetch('/chat/api/kb/files');
    const data = await res.json();
    const selected = new Set(JSON.parse(localStorage.getItem('chat_selected_kb') || '[]'));
    kbStatus.textContent = `${data.files.length} 个文件 · ${data.chunks} 个片段`;
    if (!data.files.length) {
      kbFilesEl.innerHTML = '<span class="kb-empty">暂无知识库文件，请上传 .md 或 .txt</span>';
      return;
    }
    kbFilesEl.innerHTML = data.files.map(name => {
      const checked = selected.size === 0 || selected.has(name) ? 'checked' : '';
      return `<label class="kb-chip"><input type="checkbox" value="${name.replace(/"/g,'&quot;')}" ${checked}>${name}</label>`;
    }).join('');
    kbFilesEl.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.addEventListener('change', saveSelectedKb));
    saveSelectedKb();
  } catch (err) {
    kbStatus.textContent = `加载失败：${err.message}`;
  }
}
function getSelectedKb() {
  return [...kbFilesEl.querySelectorAll('input[type="checkbox"]:checked')].map(x => x.value);
}
function saveSelectedKb() {
  localStorage.setItem('chat_selected_kb', JSON.stringify(getSelectedKb()));
}
kbUploadInput?.addEventListener('change', async () => {
  const files = [...(kbUploadInput.files || [])];
  if (!files.length) return;
  kbStatus.textContent = '正在上传...';
  try {
    const fd = new FormData();
    files.forEach(f => fd.append('files', f));
    const res = await fetch('/chat/api/kb/upload', { method: 'POST', body: fd });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    kbUploadInput.value = '';
    await loadKbFiles();
    addMessage('assistant', `知识库已上传：${data.saved.join(', ')}`);
  } catch (err) {
    kbStatus.textContent = `上传失败：${err.message}`;
  }
});

function addMessage(role, text, extraClass='') {
  const row = document.createElement('div');
  row.className = `msg ${role} ${extraClass}`.trim();
  const avatar = document.createElement('div');
  avatar.className = 'avatar';
  avatar.textContent = role === 'user' ? '你' : '☁️';
  const bubble = document.createElement('div');
  bubble.className = 'bubble';
  bubble.textContent = text;
  row.append(avatar, bubble);
  messagesEl.append(row);
  messagesEl.scrollTop = messagesEl.scrollHeight;
  return row;
}
function autosize() { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 160) + 'px'; }
input.addEventListener('input', autosize);
input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); form.requestSubmit(); } });
imageInput.addEventListener('change', () => {
  const f = imageInput.files?.[0];
  fileHint.textContent = f ? `已选择：${f.name} (${Math.round(f.size/1024)} KB)` : '';
});
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = input.value.trim();
  const file = imageInput.files?.[0];
  if (!text && !file) return;
  addMessage('user', file ? `${text || '请分析这张图片'}\n[图片：${file.name}]` : text);
  input.value = ''; autosize(); fileHint.textContent = '';
  const thinking = addMessage('assistant', '正在思考...', 'thinking');
  sendBtn.disabled = true;
  try {
    const fd = new FormData();
    fd.append('sessionId', sessionId);
    fd.append('message', text || '请分析这张图片。');
    fd.append('selectedKb', JSON.stringify(getSelectedKb()));
    fd.append('useWebSearch', webSearchToggle?.checked ? 'true' : 'false');
    if (file) fd.append('image', file);
    imageInput.value = '';
    const res = await fetch('/chat/api/chat', { method: 'POST', body: fd });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    sessionId = data.sessionId || sessionId;
    localStorage.setItem('chat_session_id', sessionId);
    thinking.querySelector('.bubble').textContent = data.answer || '没有返回内容。';
    thinking.classList.remove('thinking');
  } catch (err) {
    thinking.querySelector('.bubble').textContent = `出错了：${err.message}`;
    thinking.classList.remove('thinking');
  } finally { sendBtn.disabled = false; }
});
resetBtn.addEventListener('click', async () => {
  await fetch('/chat/api/reset', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ sessionId }) }).catch(()=>{});
  sessionId = crypto.randomUUID();
  localStorage.setItem('chat_session_id', sessionId);
  messagesEl.innerHTML = '';
  addMessage('assistant', '会话已清空。我们重新开始吧。');
});

loadHistory();
loadKbFiles();

webSearchToggle.checked = localStorage.getItem('chat_use_web_search') === 'true';
webSearchToggle.addEventListener('change', () => localStorage.setItem('chat_use_web_search', webSearchToggle.checked ? 'true' : 'false'));

contextToggle?.addEventListener('click', () => { contextCard.classList.toggle('open'); });
