'use strict';

require('dotenv').config();
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const multer = require('multer');

const app = express();
const PORT = Number(process.env.PORT || 3100);
const HOST = process.env.HOST || '127.0.0.1';
const BASE_URL = (process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/(?:chat\/completions)?$/, '');
const API_KEY = process.env.OPENAI_API_KEY || '';
const MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini';
const TAVILY_API_KEY = process.env.TAVILY_API_KEY || '';
const WEB_SEARCH_MAX_RESULTS = Math.max(1, Math.min(Number(process.env.WEB_SEARCH_MAX_RESULTS || 5), 8));
const KB_DIR = process.env.KB_DIR || path.join(__dirname, 'kb');
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const SESSION_DIR = path.join(DATA_DIR, 'sessions');
const KB_MAX_CHARS = Math.max(1000, Math.min(Number(process.env.KB_MAX_CHARS || 6000), 20000));
let kbCache = { loadedAt: 0, docs: [] };

if (!API_KEY) console.warn('[WARN] OPENAI_API_KEY is not set; chat requests will fail.');

app.disable('x-powered-by');
app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      "default-src": ["'self'"],
      "script-src": ["'self'"],
      "style-src": ["'self'", "'unsafe-inline'"],
      "img-src": ["'self'", "data:", "blob:"],
      "connect-src": ["'self'"],
      "font-src": ["'self'", "data:"],
      "object-src": ["'none'"],
      "base-uri": ["'self'"],
      "form-action": ["'self'"]
    }
  },
  crossOriginEmbedderPolicy: false
}));
app.use(express.json({ limit: '8mb' }));
app.use(express.static('public', { maxAge: '1h', index: 'index.html' }));

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    if (/^image\/(png|jpe?g|webp|gif)$/.test(file.mimetype || '')) return cb(null, true);
    cb(new Error('只允许上传 PNG/JPG/WebP/GIF 图片'));
  }
});

const kbUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 2 * 1024 * 1024, files: 5 },
  fileFilter: (_req, file, cb) => {
    if (/\.(md|txt)$/i.test(file.originalname || '') || /^text\//.test(file.mimetype || '')) return cb(null, true);
    cb(new Error('知识库只允许上传 .md 或 .txt 文件'));
  }
});

const sessions = new Map();
fs.mkdirSync(SESSION_DIR, { recursive: true });
const MAX_MESSAGES = Math.max(20, Math.min(Number(process.env.MAX_MESSAGES || 80), 200));
const SYSTEM_PROMPT = process.env.SYSTEM_PROMPT || '你是 caolaobancloud.cloud 的网页聊天助手，回答要清晰、简洁、友好。可以理解用户上传的图片。';



async function tavilySearch(query) {
  if (!TAVILY_API_KEY) return '';
  const body = { query: String(query || '').slice(0, 400), max_results: WEB_SEARCH_MAX_RESULTS, search_depth: 'basic', include_answer: true };
  const resp = await fetch('https://api.tavily.com/search', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${TAVILY_API_KEY}` },
    body: JSON.stringify(body)
  });
  const raw = await resp.text();
  let data; try { data = JSON.parse(raw); } catch { data = { error: raw }; }
  if (!resp.ok) throw new Error(data?.error || data?.message || raw.slice(0, 300));
  const lines = [];
  if (data.answer) lines.push(`搜索摘要：${data.answer}`);
  for (const [i, r] of (data.results || []).slice(0, WEB_SEARCH_MAX_RESULTS).entries()) {
    lines.push(`[搜索结果 ${i + 1}] ${r.title || ''}\nURL: ${r.url || ''}\n摘要: ${r.content || r.snippet || ''}`);
  }
  return lines.join('\n\n');
}

function tokenize(text) {
  const words = String(text || '').toLowerCase().match(/[a-z0-9_\-\.]{2,}|[\u4e00-\u9fa5]{2,}/g) || [];
  return [...new Set(words)].slice(0, 80);
}

function splitDoc(text, file) {
  const chunks = [];
  const parts = String(text || '').split(/\n(?=#{1,6}\s+)/g);
  for (const part of parts) {
    const clean = part.trim();
    if (!clean) continue;
    for (let i = 0; i < clean.length; i += 1800) {
      chunks.push({ file, text: clean.slice(i, i + 1800) });
    }
  }
  return chunks;
}

function loadKnowledgeBase(force = false) {
  const now = Date.now();
  if (!force && now - kbCache.loadedAt < 30000) return kbCache.docs;
  const docs = [];
  try {
    fs.mkdirSync(KB_DIR, { recursive: true });
    const files = fs.readdirSync(KB_DIR).filter(name => /\.(md|txt)$/i.test(name));
    for (const name of files) {
      const full = path.join(KB_DIR, name);
      if (!full.startsWith(KB_DIR)) continue;
      const stat = fs.statSync(full);
      if (!stat.isFile() || stat.size > 2 * 1024 * 1024) continue;
      docs.push(...splitDoc(fs.readFileSync(full, 'utf8'), name));
    }
  } catch (err) {
    console.error('[kb] load failed:', err.message);
  }
  kbCache = { loadedAt: now, docs };
  return docs;
}

function retrieveKnowledge(query, selectedFiles = []) {
  const terms = tokenize(query);
  if (!terms.length) return '';
  const allowed = Array.isArray(selectedFiles) ? selectedFiles.map(String).filter(Boolean) : [];
  const sourceDocs = loadKnowledgeBase().filter(doc => !allowed.length || allowed.includes(doc.file));
  const scored = sourceDocs.map(doc => {
    const lower = doc.text.toLowerCase();
    let score = 0;
    for (const t of terms) if (lower.includes(t)) score += t.length > 2 ? 2 : 1;
    return { ...doc, score };
  }).filter(x => x.score > 0).sort((a, b) => b.score - a.score).slice(0, 5);
  if (!scored.length) return '';
  let out = scored.map((x, i) => `[知识库片段 ${i + 1} · ${x.file}]\n${x.text}`).join('\n\n---\n\n');
  if (out.length > KB_MAX_CHARS) out = out.slice(0, KB_MAX_CHARS) + '\n...[知识库内容已截断]';
  return out;
}

function safeSessionId(id) {
  return String(id || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 64) || crypto.randomUUID();
}
function sessionFile(sid) {
  return path.join(SESSION_DIR, `${sid}.json`);
}
function normalizeMessages(value) {
  if (!Array.isArray(value)) return [];
  return value
    .filter(m => m && ['user', 'assistant'].includes(m.role))
    .map(m => ({ role: m.role, content: cleanText(m.content, 20000), ts: Number(m.ts || Date.now()) }))
    .filter(m => m.content)
    .slice(-MAX_MESSAGES);
}
function loadSessionFromDisk(sid) {
  try {
    const file = sessionFile(sid);
    if (!file.startsWith(SESSION_DIR)) return [];
    if (!fs.existsSync(file)) return [];
    const data = JSON.parse(fs.readFileSync(file, 'utf8'));
    return normalizeMessages(data.messages);
  } catch (err) {
    console.error('[session] load failed:', err.message);
    return [];
  }
}
function saveSessionToDisk(sid, messages) {
  try {
    fs.mkdirSync(SESSION_DIR, { recursive: true });
    const file = sessionFile(sid);
    if (!file.startsWith(SESSION_DIR)) return;
    const payload = { sessionId: sid, updatedAt: new Date().toISOString(), messages: normalizeMessages(messages) };
    fs.writeFileSync(`${file}.tmp`, JSON.stringify(payload, null, 2));
    fs.renameSync(`${file}.tmp`, file);
  } catch (err) {
    console.error('[session] save failed:', err.message);
  }
}
function deleteSessionFromDisk(sid) {
  try {
    const file = sessionFile(sid);
    if (file.startsWith(SESSION_DIR) && fs.existsSync(file)) fs.unlinkSync(file);
  } catch (err) {
    console.error('[session] delete failed:', err.message);
  }
}
function getSession(id) {
  const sid = safeSessionId(id);
  if (!sessions.has(sid)) sessions.set(sid, loadSessionFromDisk(sid));
  return { sid, messages: sessions.get(sid) };
}
function cleanText(value, max = 6000) {
  return String(value || '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').slice(0, max).trim();
}
app.get('/api/health', (_req, res) => res.json({ ok: true, model: MODEL, kbDocs: loadKnowledgeBase().length, webSearch: Boolean(TAVILY_API_KEY), persistentSessions: true }));
app.get('/api/history', (req, res) => {
  const { sid, messages } = getSession(req.query.sessionId);
  res.json({ ok: true, sessionId: sid, messages: normalizeMessages(messages) });
});
app.post('/api/kb/reload', (_req, res) => { loadKnowledgeBase(true); res.json({ ok: true, chunks: kbCache.docs.length }); });

function safeKbName(name) {
  const base = path.basename(String(name || 'knowledge.md')).replace(/[^a-zA-Z0-9_.\-一-龥]/g, '_').slice(0, 120);
  return /\.(md|txt)$/i.test(base) ? base : `${base}.txt`;
}

app.get('/api/kb/files', (_req, res) => {
  loadKnowledgeBase(true);
  const files = [...new Set(kbCache.docs.map(d => d.file))].sort();
  res.json({ ok: true, files, chunks: kbCache.docs.length });
});

app.post('/api/kb/upload', kbUpload.array('files', 5), (req, res) => {
  try {
    fs.mkdirSync(KB_DIR, { recursive: true });
    const saved = [];
    for (const file of req.files || []) {
      const name = safeKbName(file.originalname);
      const full = path.join(KB_DIR, name);
      if (!full.startsWith(KB_DIR)) throw new Error('非法文件路径');
      fs.writeFileSync(full, file.buffer);
      saved.push(name);
    }
    loadKnowledgeBase(true);
    res.json({ ok: true, saved, files: [...new Set(kbCache.docs.map(d => d.file))].sort(), chunks: kbCache.docs.length });
  } catch (err) {
    res.status(400).json({ error: err.message || '上传失败' });
  }
});
app.post('/api/reset', (req, res) => {
  const sid = safeSessionId(req.body?.sessionId);
  if (sid) {
    sessions.delete(sid);
    deleteSessionFromDisk(sid);
  }
  res.json({ ok: true });
});
app.post('/api/chat', upload.single('image'), async (req, res) => {
  try {
    if (!API_KEY) return res.status(500).json({ error: '服务端未配置 OPENAI_API_KEY' });
    const { sid, messages } = getSession(req.body.sessionId);
    const text = cleanText(req.body.message);
    let selectedKb = [];
    try { selectedKb = JSON.parse(req.body.selectedKb || '[]'); } catch { selectedKb = []; }
    const useWebSearch = String(req.body.useWebSearch || '') === 'true';
    if (!text && !req.file) return res.status(400).json({ error: '请输入消息或上传图片' });
    const content = [];
    if (text) content.push({ type: 'text', text });
    if (req.file) content.push({ type: 'image_url', image_url: { url: `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}` } });
    const userMessage = { role: 'user', content };
    const kbContext = retrieveKnowledge(text, selectedKb);
    let webContext = '';
    if (useWebSearch && text) {
      try { webContext = await tavilySearch(text); }
      catch (err) { webContext = `联网搜索失败：${err.message}`; }
    }
    const contextBlocks = [];
    if (kbContext) contextBlocks.push(`以下是从本地知识库检索到的相关资料。请优先依据资料回答；如果资料不足，请明确说明。\n\n${kbContext}`);
    if (webContext) contextBlocks.push(`以下是联网搜索结果。请结合来源回答，涉及时效信息时优先参考搜索结果。\n\n${webContext}`);
    const systemContent = contextBlocks.length ? `${SYSTEM_PROMPT}\n\n${contextBlocks.join('\n\n==========\n\n')}` : SYSTEM_PROMPT;
    const payloadMessages = [{ role: 'system', content: systemContent }, ...messages.slice(-MAX_MESSAGES), userMessage];
    const upstream = await fetch(`${BASE_URL}/chat/completions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${API_KEY}` },
      body: JSON.stringify({ model: MODEL, messages: payloadMessages, temperature: 0.7 })
    });
    const raw = await upstream.text();
    let data; try { data = JSON.parse(raw); } catch { data = { error: raw }; }
    if (!upstream.ok) {
      console.error('[chat] upstream error', upstream.status, raw.slice(0, 800));
      return res.status(upstream.status).json({ error: data?.error?.message || data?.message || raw.slice(0, 500) });
    }
    const answer = data?.choices?.[0]?.message?.content || '没有返回内容。';
    const now = Date.now();
    messages.push(text ? { role: 'user', content: text, ts: now } : { role: 'user', content: '[图片]', ts: now }, { role: 'assistant', content: answer, ts: Date.now() });
    while (messages.length > MAX_MESSAGES) messages.shift();
    saveSessionToDisk(sid, messages);
    res.json({ ok: true, sessionId: sid, answer });
  } catch (err) {
    console.error('[chat] failed:', err);
    res.status(500).json({ error: err.message || '服务异常' });
  }
});
app.use((err, _req, res, _next) => res.status(400).json({ error: err.message || '请求错误' }));
app.listen(PORT, HOST, () => console.log(`Chat running at http://${HOST}:${PORT}`));
